﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Avidclan_Website.Models
{
    public class HeaderMenu
    {
        public string MenuName { get; set; }
        public bool Status { get; set; }
    }
}